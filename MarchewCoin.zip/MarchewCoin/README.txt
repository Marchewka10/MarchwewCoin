Zanim zaczniejsz musisz zrobic te rzeczy by program dzialał
1. Przycisk Win + r
2. Wpisz tam cmd
3. ENTER
4. Wpisz pip install python
5. ENTER
6. Wpisz pip install random
7. ENTER
8. Wpisz pip install colorama
9. ENTER
10. Możesz zamknac to okno nastepnie w folderze w którym jest ten plik uruchom plik AVR_Miner.cmd i gotowe do zobaczenia ile masz na koncie uruchom
MarchwCoin.py i to wszystko dzwon jak cos nie bedzie dzialalo