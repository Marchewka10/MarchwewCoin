import Setup as SU
from time import sleep as SL
print("MarchwCoin: ", SU.COIN)
SL(5)